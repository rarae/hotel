import com.hotel.utils.DateUtil;

import java.text.SimpleDateFormat;
import java.util.Date;

public class test {


    public static void main(String[] args) {
        System.out.println(DateUtil.duration2days("2764800"));
    }
}